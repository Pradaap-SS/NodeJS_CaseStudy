const path = require('path'); // helper function for navigation

module.exports = path.dirname(process.mainModule.filename);